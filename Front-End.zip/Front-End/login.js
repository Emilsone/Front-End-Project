// javascript code//
function validateForm(e){
    e.preventDefault();
  let name = document.myForm.usersname.value;
    let email = document.myForm.email.value;
    
    if (name.length<1) {
        document.getElementById('error-name').innerHTML = " Please Enter Your Name *"
    }
    if (email.length<1) {
        document.getElementById('error-email').innerHTML = " Please Enter Your Email *";
    }

    if(name.length<1 || email.length<1){
        // document.forms["myForm"].submit();
        // console.log('test')
        return false;
    }
}