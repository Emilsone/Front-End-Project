
const para= document.querySelector("p");
para.addEventListener("click", updateName);

function updateName(){
    let name = prompt("Enter your name");
    para.textContent =`Welcome  : ${name}`;
}